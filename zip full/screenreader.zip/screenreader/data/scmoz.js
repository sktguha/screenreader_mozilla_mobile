/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
  var w,ran;
    /**
     * the control div
     */   
    var div;
    //the range object
    var ran;
    //window.onerror=function(e){alert("error: "+e);}
    document.onreadystatechange = function () {
    if (document.readyState == "interactive") {
        init();
        console.log("init ,from screenreader mozilla injected");
  div.getElementsByTagName('span')[0].innerHTML="Ready. make sure server application is running and image loading is on";
    }
}
    
    
  
    //alert(div.innerHTML);
    function init(){
    w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null,false);        
    ran=new Range();
    var sp=document.createElement("div");
    sp.innerHTML=" ";
    document.body.insertBefore(sp, document.body.firstChild);
    ran.selectNodeContents(sp);
    window.getSelection().addRange(ran);
    div=document.createElement("div");
    div.style.position="fixed";
    div.style.bottom="1%";
    div.style.backgroundColor="yellow";
    div.style.opacity=0.8;
    div.innerHTML="<table><tr><td><input type='button' value='Prev sent'/></td><td><input type='button' value='Next sent'/></td><td><input type='button' value='jump/init'/></td><td><input type='button' value='prev punc'/></td><td><input type='button' value='next punc'/></td><td><td><input type='button' value='repeat'/></td><td><input type='button' value='stop'/></td></tr></table><span id='m'></span>";
    //div.innerHTML="<input type='button' id='1' value='Prev sentence'/><input type='button' id='2' value='Next sentence' /><input type='button' id='3' value='jump/init'/><span id='m'></span>";
    document.body.appendChild(div);
    //to fix bug in firefox where the cdiv can't get focus
    

    var pre=document.createElement("pre");
    for(var i=0;i<60;i++)
    {   pre.innerHTML+="  \n";}
    //document.body.appendChild(pre);
  insertAfter(document.body.lastChild,pre);
    document.onkeypress=handler;
    var ba=div.querySelectorAll('input');
    window.onblur=function(){
        speak(" ");
        }
    //alert(ba);
    ba[0].addEventListener("click", mbl);
    ba[1].addEventListener("click", mfl);
    ba[2].addEventListener("click", jump);
    ba[3].addEventListener("click", mbp);
    ba[4].addEventListener("click", mfp);
    ba[5].addEventListener("click", function(){
        svs();
        speak(window.getSelection().toString());
        rts();
        });
    ba[6].addEventListener("click", function(){
        speak(" ")
        });
    if (!String.prototype.hasOwnProperty("endsWith")) {
    Object.defineProperty(String.prototype, 'endsWith', {
        enumerable: false,
        configurable: false,
        writable: false,
        value: function (searchString, position) {
            position = position || this.length;
            position = position - searchString.length;
            var lastIndex = this.lastIndexOf(searchString);
            return lastIndex !== -1 && lastIndex === position;
        }
    });
}
    if (!String.prototype.hasOwnProperty("startsWith")) {
  Object.defineProperty(String.prototype, 'startsWith', {
    enumerable: false,
    configurable: false,
    writable: false,
    value: function (searchString, position) {
      position = position || 0;
      return this.indexOf(searchString, position) === position;
    }
  });
}
    //alert(ba[1]);
    }
    
    function insertAfter(referenceNode, newNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
}
    
    function jump()
    {
        //alert('jump called');
        div.style.backgroundColor="red";
        div.getElementsByTagName("span")[0].innerHTML="select any text within 4 sec";
        
        setTimeout(function(){
        div.getElementsByTagName("span")[0].innerHTML="select any text within 3 sec"; 
        },1000);
        setTimeout(function(){
        div.getElementsByTagName("span")[0].innerHTML="select any text within 2 sec"; 
        },2000);
        setTimeout(function(){
        div.getElementsByTagName("span")[0].innerHTML="select any text within 1 sec"; 
        },3000); 
        setTimeout(mov,4000);
    }
    
    function mov(){
            try{
                if(window.getSelection().toString().length>0)
            {ran=window.getSelection().getRangeAt(0);}
            else
                {throw new error('selection empty');}
            div.getElementsByTagName("span")[0].innerHTML="";
            div.style.backgroundColor="yellow";
            div.getElementsByTagName("span")[0].innerHTML="Done jumping!! now press next line or prev line buttons etc";
            console.log('done');
            }catch(e){
            div.getElementsByTagName("span")[0].innerHTML="incorrectly done. Refer this <a href=''>Help for jumping</a>";     
            alert("Steps  (1) Press jump/init button (2) Select the text(where u want to jump) within 4 sec (3) Then wait for 'Done!!' message (4) Now use next line/prev line etc");
        }
    }
    
    function handler(e)
    {
       ;
    }
    //set range to selection
    function chk()
    {
       var sel=window.getSelection();
       if(sel.toString().length<1)
           return false;
        ran=sel.getRangeAt(0);
        return true;
    }
    /**
     * reset the selection object
     * @returns {undefined}
     */
    function rsf()
    {
        var sel=window.getSelection();
        sel.modify("move","forward","character");
        sel.modify("move","backward","character");
    }
    
    function rsb()
    {
        var sel=window.getSelection();
        sel.modify("move","backward","character");
        sel.modify("move","forward","character");
    }
    /**
     * extend forward by one char
     * @returns {undefined}
     */
    function ef()
    {
        var sel=window.getSelection();
        sel.modify("extend","forward","character");
    }
    
    /**
     * extend backward by one char
     * @returns {undefined}
     */
    function eb()
    {
        var sel=window.getSelection();
        sel.modify("extend","backward","character");
    }
    
    function mbl()
    {
        var ss='.';
        rts();
        if(chk()==false)
            {
      alert("please use jump/init functionality");
        return;    
        }
        rsb();
        //alert("mb called");
        //infinite counter limit
        var inf=10;
      var st="",old="";
        while(true)
      {   st=window.getSelection().toString();
          if((st.startsWith(".") || st.startsWith("\n"))&& st.length>3) break;
          if(st==old) inf--;
          if(inf<0)   break;
          eb();
          old=st;
        }
        speak(window.getSelection().toString());
        svs();
        mvis();
}
    
    function mfl()
    {
        var es='.';
        rts();
        if(chk()==false)
            {
      alert("please use jump/init functionality");
        return;    
        }
        rsf();
        //alert("mf called");
        //infinite counter limit
        var inf=10;
      var st="",old="";
        while(true)
      {   st=window.getSelection().toString();
          if((st.endsWith(".") || st.endsWith("\n"))&& st.length>3) break;
          if(st==old) inf--;
          if(inf<0)   break;
          ef();
          old=st;
        }
        speak(window.getSelection().toString());
        svs();
        //alert(window.getSelection().toString());
        mvis();
    //alert(ran.toString());
    }
    //save selection state .called after
    
    
    function mbp()
    {
        var ss='.';
        rts();
        if(chk()==false)
            {
      alert("please use jump/init functionality");
        return;    
        }
        rsb();
        //alert("mb called");
        //infinite counter limit
        var inf=10;
      var st="",old="";
        while(true)
      {   st=window.getSelection().toString();
          if((st.startsWith(".") || st.startsWith("\n") || st.startsWith("?")|| st.startsWith(")")|| st.startsWith("(")|| st.startsWith(";")|| st.startsWith(",") )&& st.length>3) break;
          if(st==old) inf--;
          if(inf<0)   break;
          eb();
          old=st;
        }
        speak(window.getSelection().toString());
        svs();
        mvis();
}
    
    function mfp()
    {
        var es='.';
        rts();
        if(chk()==false)
            {
      alert("please use jump/init functionality");
        return;    
        }
        rsf();
        //alert("mf called");
        //infinite counter limit
        var inf=10;
      var st="",old="";
        while(true)
      {   st=window.getSelection().toString();
          if((st.endsWith(".") || st.endsWith("\n")|| st.endsWith(")")|| st.endsWith("(")|| st.endsWith(",")|| st.endsWith(";"))&& st.length>3) break;
          if(st==old) inf--;
          if(inf<0)   break;
          ef();
          old=st;
        }
        speak(window.getSelection().toString());
        svs();
        //alert(window.getSelection().toString());
        mvis();
    //alert(ran.toString());
    }
    
    function svs()
    {
        var sel=window.getSelection();
        if(sel.toString().length<1)
            return;
        ran=sel.getRangeAt(0);
    }
    //restore selection. called before
    function rts()
    {
        var sel=window.getSelection();
        //if a selection already exists , don't restore it 
        if(sel.toString().length>0)
            return;
        sel.removeAllRanges();
        sel.addRange(ran);
    }
    
    //audio.src ='http://translate.google.com/translate_tts?ie=utf-8&tl=en&q=Hello%20World.';

    function speak(tx)
    {
        
        var im = new Image();
        im.src="http://localhost:8085/?text="+tx+"&timestamp="+new Date().getTime()+"&url="+window.href;
        im.onload=function(e){//alert("loaded: "+e);
        }
     }
    
 function setCookie(cname,cvalue,exdays)
{
var d = new Date();
d.setTime(d.getTime()+(exdays*24*60*60*1000));
var expires = "expires="+d.toGMTString();
document.cookie = cname + "=" + cvalue + "; " + expires;
}

function getCookie(cname)
{
var name = cname + "=";
var ca = document.cookie.split(';');
for(var i=0; i<ca.length; i++) 
  {
  var c = ca[i].trim();
  if (c.indexOf(name)==0) return c.substring(name.length,c.length);
}
return "";
}
    /**
     * scroll up/down
     */
function mvis()  
{
    return;
    rts();
    var ele=window.getSelection().getRangeAt(0);        
    var sel = ele.getBoundingClientRect();               
    var dh = document.documentElement.clientHeight;       
    dh=window.innerHeight;
    var st=sel.top;
    var sb=sel.bottom;
    var db=dh; 
    var dt=0;
    var amt=0;
    if(st<0)     //too much up
    {
        //alert("st<0");
        amt=-1*dh*scf;//341 dh*scf; 
    }
    if(sb>db) //too much down
    {
        //alert("sb>db");
        amt=dh*scf; //341;    
    }
    window.scrollBy(0, amt);
    if(amt>500) 
        console.debug("scroll value too much "+amt);
}
